import React from 'react';
import { useTransactionForm } from '../../context/TransactionFormContext';
import { RoleSection } from './sections/RoleSection';
import { PropertySection } from './sections/PropertySection';
import { ClientSection } from './sections/ClientSection';
import { CommissionSection } from './sections/CommissionSection';
import { PropertyDetailsSection } from './sections/PropertyDetailsSection';
import { DocumentsSection } from './sections/DocumentsSection';
import { AdditionalInfoSection } from './sections/AdditionalInfoSection';
import { SignatureSection } from './sections/SignatureSection';
import { ConfirmationDialog } from './ConfirmationDialog';
import { Toaster } from '../ui/toaster';
import { useToast } from '../../hooks/use-toast';
import { FormProgress } from './FormProgress';
import { FormNavigation } from './components/FormNavigation';
import { motion, AnimatePresence } from 'framer-motion';
import { FormProvider, useForm } from 'react-hook-form';
import { FORM_SECTIONS } from './types';

export const TransactionForm: React.FC = () => {
  const { 
    state, 
    actions,
  } = useTransactionForm();

  const { toast } = useToast();
  const [showConfirmation, setShowConfirmation] = React.useState(false);
  const methods = useForm();

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (state.metadata.currentStep === FORM_SECTIONS.length - 1) {
      setShowConfirmation(true);
    } else {
      actions.setStep(state.metadata.currentStep + 1);
    }
  };

  const handleConfirm = async () => {
    try {
      await actions.handleSubmit();
      setShowConfirmation(false);
      toast({
        title: "Success",
        description: "Form submitted successfully!"
      });
    } catch (error) {
      console.error('Form submission failed:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit the form"
      });
    }
  };

  const handleSectionChange = (step: number) => {
    actions.setStep(step);
  };

  return (
    <div className="p-6 relative min-h-screen bg-gradient-to-b from-[#1e3a8a]/5 to-[#ffd7ba]/10">
      <div className="max-w-5xl mx-auto bg-gradient-to-br from-white to-[#ffd7ba]/20 rounded-2xl shadow-[0_10px_50px_rgba(0,0,0,0.2),0_0_0_1px_rgba(0,0,0,0.1)] backdrop-blur-sm relative overflow-hidden border border-white/50">
        <div className="flex">
          <div className="flex-none">
            <FormProgress
              sections={[...FORM_SECTIONS]}
              currentSection={state.metadata.currentStep}
              onSectionClick={handleSectionChange}
              canAccessSection={() => true}
              isSectionComplete={() => true}
              hasError={() => false}
            />
          </div>

          <div className="flex-grow relative min-h-[600px] bg-gradient-to-br from-white/80 via-white/60 to-white/80">
            <div className="absolute inset-0">
              <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center opacity-5 pointer-events-none" />
              <div className="absolute inset-0 bg-gradient-to-br from-[#1e3a8a]/5 via-transparent to-[#ffd7ba]/5" />
            </div>
            <div className="p-8 relative h-full">
              <FormProvider {...methods}>
                <form onSubmit={handleFormSubmit} className="space-y-8 relative">
                  {state.metadata.isSubmitting && (
                    <div className="absolute inset-0 bg-white/50 backdrop-blur-sm flex items-center justify-center z-50">
                      <div className="flex flex-col items-center gap-4">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1e3a8a]"></div>
                        <p className="text-[#1e3a8a] font-medium">Processing...</p>
                      </div>
                    </div>
                  )}

                  <AnimatePresence mode="wait">
                    <motion.div
                      key={state.metadata.currentStep}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                    >
                      {state.metadata.currentStep === 0 && <RoleSection />}
                      {state.metadata.currentStep === 1 && <PropertySection />}
                      {state.metadata.currentStep === 2 && <ClientSection />}
                      {state.metadata.currentStep === 3 && <CommissionSection />}
                      {state.metadata.currentStep === 4 && <PropertyDetailsSection />}
                      {state.metadata.currentStep === 5 && <DocumentsSection />}
                      {state.metadata.currentStep === 6 && <AdditionalInfoSection />}
                      {state.metadata.currentStep === 7 && <SignatureSection />}
                    </motion.div>
                  </AnimatePresence>

                  <FormNavigation
                    currentSection={state.metadata.currentStep}
                    totalSections={FORM_SECTIONS.length}
                    onPrevious={() => handleSectionChange(state.metadata.currentStep - 1)}
                    onNext={() => handleSectionChange(state.metadata.currentStep + 1)}
                    onReset={actions.resetForm}
                    onSubmit={handleFormSubmit}
                    isSubmitting={state.metadata.isSubmitting}
                    completedSections={[]}
                  />
                </form>
              </FormProvider>
            </div>
          </div>
        </div>
      </div>

      <ConfirmationDialog
        open={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={handleConfirm}
      />
      
      <Toaster />
    </div>
  );
};
