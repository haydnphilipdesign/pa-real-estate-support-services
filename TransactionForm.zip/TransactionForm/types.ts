export const FORM_SECTIONS = [
  'Role',
  'Property',
  'Client',
  'Commission',
  'Property Details',
  'Documents',
  'Additional Info',
  'Sign'
] as const;

export type AgentRole = "Buyer's Agent" | "Listing Agent" | "Dual Agent" | "";
export type MaritalStatus = "Single" | "Married" | "Divorce" | "Widowed";
export type CommissionType = "Percentage" | "Fixed";
export type CommissionBase = "Full Price" | "Net Price";
export type TCFeePaidBy = "Client" | "Agent";
export type AccessType = "Electronic Lock Box" | "Call Occupant";
export type PropertyStatus = "Vacant" | "Occupied";
export type WarrantyPaidBy = "Seller" | "Buyer" | "Agent";
export type ClientDesignation = "Buyer" | "Seller" | "";

export type ValidationState = 'valid' | 'invalid' | 'warning' | null | undefined;

export interface ClientInfo {
  name: string;
  address: string;
  email: string;
  phone: string;
  maritalStatus: MaritalStatus;
  designation: ClientDesignation;
}

export interface TransactionFormData {
  // Role Information
  role: AgentRole;
  
  // Property Information
  mlsNumber: string;
  propertyAddress: string;
  salePrice: string;
  townshipName: string;
  
  // Property Status
  winterizedStatus: 'not_winterized' | 'winterized' | 'partial' | 'not_applicable';
  accessType: 'lockbox' | 'key' | 'appointment' | 'occupied' | 'other';
  updateMlsStatus: boolean;
  
  // Client Information
  clients: ClientInfo[];
  
  // Commission Information
  commissionBase: CommissionBase;
  totalCommission: string;
  listingAgentCommissionType: CommissionType;
  listingAgentCommission: string;
  buyersAgentCommissionType: CommissionType;
  buyersAgentCommission: string;
  buyerPaidCommission: string;
  
  // Referral Information
  referralParty: string;
  brokerEIN: string;
  referralFee: string;
  
  // Property Details
  resaleCertRequired: boolean;
  hoa: string;
  coRequired: boolean;
  municipalityTownship: string;
  firstRightOfRefusal: boolean;
  firstRightOfRefusalName: string;
  attorneyRepresentation: boolean;
  attorneyName: string;
  homeWarrantyPurchased: boolean;
  homeWarrantyCompany: string;
  warrantyCost: string;
  warrantyPaidBy: WarrantyPaidBy;
  
  // Additional Information
  titleCompany: string;
  tcFeePaidBy: TCFeePaidBy;
  propertyStatus: PropertyStatus;
  accessInformation: AccessType;
  accessCode: string;
  updateMLS: boolean;
  acknowledgeDocuments: boolean;
  
  // Additional Information Fields
  specialInstructions: string;
  urgentIssues: string;
  additionalNotes: string;
  
  // Documents
  requiredDocuments: string[];
  
  // Final Details
  agentName: string;
  dateSubmitted: string;
}

export interface FormSectionProps {
  formData: TransactionFormData;
  onUpdate: <K extends keyof TransactionFormData>(field: K, value: TransactionFormData[K]) => void;
  role?: AgentRole;
  getValidationState: (field: keyof TransactionFormData) => ValidationState;
  getFieldError: (field: keyof TransactionFormData) => string | undefined;
}

export type StepToSection = {
  [key: number]: keyof TransactionFormData;
};

export const stepToSection: StepToSection = {
  0: 'role',
  1: 'propertyAddress',
  2: 'clients',
  3: 'commissionBase',
  4: 'propertyStatus',
  5: 'requiredDocuments',
  6: 'additionalNotes',
  7: 'agentName'
} as const;

export interface SignatureSectionProps extends Omit<FormSectionProps, 'role'> {}

export interface RoleSectionProps {
  role: AgentRole;
  onUpdate: (field: keyof TransactionFormData, value: any) => void;
}

export interface FormProgressProps {
  sections: readonly typeof FORM_SECTIONS[number][];
  currentSection: number;
  onSectionClick: (index: number) => void;
  canAccessSection: (index: number) => boolean;
  isSectionComplete: (index: number) => boolean;
  hasError: (index: number) => boolean;
}

// Required document lists for each role (COMPLIANCE REQUIRED)
export const BUYERS_AGENT_DOCUMENTS = [
  "Agreement of Sale & Addenda",
  "Attorney Review Clause (if applicable)",
  "KW Affiliate Services Disclosure",
  "KW Affiliate Services Addendum",
  "KW Wire Fraud Advisory",
  "KW Home Warranty Waiver",
  "Consumer Notice",
  "Buyer's Agency Contract",
  "Prequalification/Proof of Funds",
  "Seller's Property Disclosure",
  "Lead Based Paint Disclosure (if applicable)",
  "Deposit Money Notice",
  "Buyer's Estimated Costs",
  "Cooperating Broker's Compensation",
  "KPSS ABA (if using Keystone Premier Settlement)",
  "For Your Protection Notice (if applicable)",
  "Referral Agreement & W-9 (if applicable)"
];

export const LISTING_AGENT_DOCUMENTS = [
  "Agreement of Sale and Addenda",
  "Buyer's Prequalification/Preapproval Letter/Proof of Funds",
  "Attorney Review Clause (if applicable)",
  "KW Affiliate Services Addendum",
  "Seller's Property Disclosure",
  "Lead Based Paint Disclosure (if applicable)",
  "Seller's Estimated Costs",
  "KW Wire Fraud Advisory",
  "Dual Agency Disclosure (if applicable)",
  "Referral Agreement & W-9 (if applicable)",
  "KW Home Warranty Waiver",
  "Cooperating Broker's Compensation"
];

export const DUAL_AGENT_DOCUMENTS = [
  "Agreement of Sale & Addenda",
  "Attorney Review Clause (if applicable)",
  "KW Affiliate Services Disclosure",
  "KW Affiliate Services Addendum",
  "Consumer Notice",
  "Buyer's Agency Contract",
  "Prequalification/Proof of Funds",
  "Seller's Property Disclosure",
  "Lead Based Paint Disclosure (if applicable)",
  "Deposit Money Notice",
  "Buyer's Estimated Costs",
  "Seller's Estimated Costs",
  "KPSS ABA (if using Keystone Premier Settlement)",
  "For Your Protection Notice (if applicable)",
  "Referral Agreement & W-9 (if applicable)",
  "KW Wire Fraud Advisory",
  "KW Home Warranty Waiver",
  "Dual Agency Disclosure"
];
