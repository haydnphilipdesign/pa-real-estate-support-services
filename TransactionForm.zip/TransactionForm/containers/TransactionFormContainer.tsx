import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, CheckCircle, DollarSign, MapPin, MessageSquare, Users, Home, FileCheck } from 'lucide-react';
import { TransactionFormProvider, useTransactionForm } from '../../../context/TransactionFormContext';
import { FormSection } from '../FormSection';
import { Button } from '../../ui/button';
import { Toaster } from '../../ui/toaster';
import { useToast } from '../../../hooks/use-toast';
import { FormProgress } from '../FormProgress';
import { RoleSection } from '../sections/RoleSection';
import { PropertySection } from '../sections/PropertySection';
import { ClientSection } from '../sections/ClientSection';
import { CommissionSection } from '../sections/CommissionSection';
import { PropertyDetailsSection } from '../sections/PropertyDetailsSection';
import { DocumentsSection } from '../sections/DocumentsSection';
import { AdditionalInfoSection } from '../sections/AdditionalInfoSection';
import { SignatureSection } from '../sections/SignatureSection';
import { ConfirmationDialog } from '../ConfirmationDialog';
import { validationService } from '../../../services/validation/ValidationService';
import { cn } from '../../../lib/utils';

const FORM_SECTIONS = [
  'Role',
  'Property',
  'Client',
  'Commission',
  'Property Details',
  'Documents',
  'Additional Info',
  'Sign'
] as const;

const sectionIcons = {
  'Role': FileText,
  'Property': Home,
  'Client': Users,
  'Commission': DollarSign,
  'Property Details': MapPin,
  'Documents': FileCheck,
  'Additional Info': MessageSquare,
  'Sign': CheckCircle,
} as const;

const sectionDescriptions = {
  'Role': "Select your role in this transaction to determine required documentation and commission structure.",
  'Property': "Enter accurate property details including MLS number and address.",
  'Client': "Provide client information exactly as it appears on legal documents.",
  'Commission': "Specify commission details and payment structure.",
  'Property Details': "Enter additional property-specific information.",
  'Documents': "Confirm all required documentation is complete.",
  'Additional Info': "Add any special instructions or notes.",
  'Sign': "Review and sign to complete submission."
};

const TransactionFormContent: React.FC = () => {
  const { state, actions } = useTransactionForm();
  const { toast } = useToast();
  const [showConfirmation, setShowConfirmation] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const validation = validationService.validateForm(state.data);
      if (!validation.isValid) {
        const firstErrorSection = FORM_SECTIONS.findIndex(
          section => validation.errors.some(error => error.field.toLowerCase().includes(section.toLowerCase()))
        );
        
        if (firstErrorSection !== -1) {
          actions.setStep(firstErrorSection);
        }

        toast({
          variant: "destructive",
          title: "Validation Error",
          description: "Please fix all errors before submitting."
        });
        return;
      }

      setShowConfirmation(true);
    } catch (error) {
      console.error('Form validation failed:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "An error occurred while validating the form."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirm = async () => {
    setIsSubmitting(true);
    try {
      await actions.handleSubmit();
      setShowConfirmation(false);
      toast({
        title: "Success",
        description: "Form submitted successfully!"
      });
    } catch (error) {
      console.error('Form submission failed:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit the form"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSectionClick = (index: number) => {
    if (canAccessSection(index)) {
      actions.setStep(index);
    }
  };

  const canAccessSection = (index: number): boolean => {
    if (index === 0) return true;
    
    for (let i = 0; i < index; i++) {
      const validation = validationService.validateSection(FORM_SECTIONS[i].toLowerCase(), state.data);
      if (!validation.isValid) return false;
    }
    
    return true;
  };

  const isSectionComplete = (index: number): boolean => {
    const validation = validationService.validateSection(FORM_SECTIONS[index].toLowerCase(), state.data);
    return validation.isValid;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-[1200px] mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8">
          {/* Progress Bar */}
          <FormProgress
            currentStep={state.metadata.currentStep}
            totalSteps={FORM_SECTIONS.length}
            completedSteps={state.metadata.completedSteps}
          />

          {/* Form Content */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="flex">
              {/* Navigation Sidebar */}
              <nav className="w-[280px] flex-shrink-0 bg-gray-50 border-r border-gray-200 p-4 space-y-2">
                {FORM_SECTIONS.map((section, index) => {
                  const Icon = sectionIcons[section];
                  const isComplete = isSectionComplete(index);
                  const isActive = state.metadata.currentStep === index;
                  const canAccess = canAccessSection(index);

                  return (
                    <button
                      key={section}
                      onClick={() => handleSectionClick(index)}
                      disabled={!canAccess}
                      className={cn(
                        "w-full text-left px-4 py-3 rounded-lg flex items-center gap-3",
                        "transition-colors duration-200",
                        isActive ? "bg-blue-50 text-blue-700" : 
                        canAccess ? "hover:bg-gray-100" : "opacity-50 cursor-not-allowed",
                        "disabled:cursor-not-allowed"
                      )}
                    >
                      <Icon className="w-5 h-5 flex-shrink-0" />
                      <span className="font-medium">{section}</span>
                      {isComplete && (
                        <div className="ml-auto">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </nav>

              {/* Form Section */}
              <div className="flex-1 min-h-[600px]">
                <AnimatePresence mode="wait">
                  {state.metadata.currentStep === 0 && <RoleSection key="role" />}
                  {state.metadata.currentStep === 1 && <PropertySection key="property" />}
                  {state.metadata.currentStep === 2 && <ClientSection key="client" />}
                  {state.metadata.currentStep === 3 && <CommissionSection key="commission" />}
                  {state.metadata.currentStep === 4 && <PropertyDetailsSection key="property-details" />}
                  {state.metadata.currentStep === 5 && <DocumentsSection key="documents" />}
                  {state.metadata.currentStep === 6 && <AdditionalInfoSection key="additional-info" />}
                  {state.metadata.currentStep === 7 && <SignatureSection key="signature" />}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ConfirmationDialog
        open={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={handleConfirm}
      />
      <Toaster />
    </div>
  );
};

// Wrap with provider
export const TransactionFormContainer: React.FC = () => {
  return (
    <TransactionFormProvider>
      <TransactionFormContent />
    </TransactionFormProvider>
  );
};
