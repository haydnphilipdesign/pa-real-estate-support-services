import { useState } from "react";
import { AgentRole, TransactionFormData, ClientInfo } from "./types";
import { useToast } from "../../hooks/use-toast";
import { submitToAirtable } from "../../utils/airtable";
import { format } from 'date-fns';

const initialFormData: TransactionFormData = {
  // Role Information
  role: "Buyer's Agent",
  
  // Property Information
  mlsNumber: "",
  propertyAddress: "",
  salePrice: "",
  townshipName: "",
  
  // Property Status
  winterizedStatus: "not_winterized",
  accessType: "lockbox",
  updateMlsStatus: false,
  
  // Client Information
  clients: [{
    name: '',
    address: '',
    email: '',
    phone: '',
    maritalStatus: 'Single',
    designation: ''
  }],
  
  // Commission Information
  commissionBase: "Full Price",
  totalCommission: "",
  listingAgentCommissionType: "Percentage",
  listingAgentCommission: "",
  buyersAgentCommissionType: "Percentage",
  buyersAgentCommission: "",
  buyerPaidCommission: "",
  
  // Referral Information
  referralParty: "",
  brokerEIN: "",
  referralFee: "",
  
  // Property Details
  resaleCertRequired: false,
  hoa: "",
  coRequired: false,
  municipalityTownship: "",
  firstRightOfRefusal: false,
  firstRightOfRefusalName: "",
  attorneyRepresentation: false,
  attorneyName: "",
  homeWarrantyPurchased: false,
  homeWarrantyCompany: "",
  warrantyCost: "",
  warrantyPaidBy: "Seller",
  
  // Additional Information
  titleCompany: "",
  tcFeePaidBy: "Client",
  propertyStatus: "Vacant",
  accessInformation: "Electronic Lock Box",
  accessCode: "",
  updateMLS: false,
  acknowledgeDocuments: false,
  
  // Additional Information Fields
  specialInstructions: "",
  urgentIssues: "",
  additionalNotes: "",
  
  // Documents
  requiredDocuments: [],
  
  // Final Details
  agentName: "",
  dateSubmitted: ""
};

export function useTransactionForm() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<TransactionFormData>(initialFormData);

  const updateFormData = (field: keyof TransactionFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateSection = (section: string, data: TransactionFormData): string[] => {
    const errors: string[] = [];
    
    switch (section.toLowerCase()) {
      case 'role':
        if (!data.role) errors.push("Please select your role");
        break;
        
      case 'property':
        if (!data.propertyAddress) errors.push("Property address is required");
        if (!data.salePrice) errors.push("Sale price is required");
        if (data.mlsNumber) {
          const mlsRegex = /^(?:\d{6}|PM-\d{6})$/;
          if (!mlsRegex.test(data.mlsNumber)) {
            errors.push("MLS number must be either 6 digits or PM-followed by 6 digits");
          }
        }
        break;
        
      case 'client':
        if (data.clients.length === 0) {
          errors.push("At least one client is required");
        } else {
          const primaryClient = data.clients[0];
          if (!primaryClient.name) errors.push("Client name is required");
          if (!primaryClient.address) errors.push("Client's current address is required");
          if (!primaryClient.email) errors.push("Primary email is required");
          if (!primaryClient.phone) errors.push("Primary phone number is required");
          if (!primaryClient.maritalStatus) errors.push("Marital status is required");
          if (primaryClient.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(primaryClient.email)) {
            errors.push("Please enter a valid primary email address");
          }

          // Validate additional clients if they exist
          data.clients.slice(1).forEach((client, index) => {
            if (client.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(client.email)) {
              errors.push(`Please enter a valid email address for client ${index + 2}`);
            }
          });
        }
        break;
        
      case 'commission':
        if (!data.commissionBase) errors.push("Commission base is required");
        if (!data.totalCommission) errors.push("Total commission amount is required");
        if (data.role !== "Buyer's Agent" && !data.listingAgentCommission) {
          errors.push("Listing Agent Commission is required");
        }
        if (!data.buyersAgentCommission) errors.push("Buyers Agent Commission is required");
        
        // Commission amount validations
        const total = parseFloat(data.totalCommission || "0");
        const listing = parseFloat(data.listingAgentCommission || "0");
        const buyer = parseFloat(data.buyersAgentCommission || "0");
        const sale = parseFloat(data.salePrice || "0");
        
        if (total > sale) {
          errors.push("Total commission cannot exceed the sale price");
        }
        if (listing + buyer > total) {
          errors.push("Combined agent commissions cannot exceed total commission");
        }
        break;
        
      case 'details':
        if (data.resaleCertRequired && !data.hoa) {
          errors.push("HOA name is required when resale certificate is required");
        }
        if (data.coRequired && !data.municipalityTownship) {
          errors.push("Municipality/Township name is required when CO is required");
        }
        if (data.firstRightOfRefusal && !data.firstRightOfRefusalName) {
          errors.push("Please specify who has first right of refusal");
        }
        if (data.attorneyRepresentation && !data.attorneyName) {
          errors.push("Attorney name is required when attorney representation is involved");
        }
        if (data.homeWarrantyPurchased) {
          if (!data.homeWarrantyCompany) errors.push("Home Warranty company is required");
          if (!data.warrantyCost) errors.push("Warranty cost is required");
          if (!data.warrantyPaidBy) errors.push("Please specify who pays for the warranty");
        }
        break;
        
      case 'documents':
        if (data.requiredDocuments.length === 0) {
          errors.push("Please select at least one required document");
        }
        break;
        
      case 'additional info':
        // This section is optional, no validation required
        break;
        
      case 'sign':
        if (!data.agentName) errors.push("Please provide your signature");
        break;
    }
    
    return errors;
  };

  const handleSubmit = async () => {
    const errors = validateSection('sign', formData);
    if (errors.length > 0) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: errors.join(", ")
      });
      return;
    }

    try {
      const apiKey = import.meta.env.VITE_AIRTABLE_API_KEY;
      if (!apiKey) {
        throw new Error('Airtable API key not found in environment variables');
      }
      
      // Ensure the API key starts with 'pat'
      if (!apiKey.startsWith('pat')) {
        throw new Error('Invalid Airtable API key format');
      }

      await submitToAirtable(formData, apiKey);
      toast({
        title: "Success!",
        description: "Your transaction form has been submitted successfully."
      });
      
      // Reset form after successful submission
      setFormData({
        ...initialFormData,
        dateSubmitted: format(new Date(), 'yyyy-MM-dd') // Keep today's date
      });
    } catch (error) {
      console.error('Form submission error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit the form. Please try again."
      });
    }
  };

  return {
    formData,
    updateFormData,
    handleSubmit,
    validateSection
  };
} 