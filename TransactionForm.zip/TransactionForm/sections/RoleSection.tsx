import React from 'react';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { Alert, AlertTitle, AlertDescription } from '../../ui/alert';
import { useFormSection } from '../../../hooks/useFormSection';
import { AgentRole } from '../types';

export const RoleSection: React.FC = () => {
  const { formData, updateField, getFieldValidationState, getFieldError } = useFormSection({
    sectionName: 'role',
    sectionIndex: 0
  });

  const roleOptions: AgentRole[] = [
    'Listing Agent',
    'Buyer\'s Agent',
    'Dual Agent'
  ];

  return (
    <FormSectionContainer>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">Role Selection</h2>
          <div className="text-sm text-red-500">* Required</div>
        </div>

        <div className="grid grid-cols-1 gap-y-6">
          <FormFieldWrapper
            label="Your Role"
            required
            error={getFieldValidationState('role') === 'invalid' ? getFieldError('role') : undefined}
            warning={getFieldValidationState('role') === 'warning' ? getFieldError('role') : undefined}
          >
            <Select value={formData.role} onValueChange={(value) => updateField('role', value as AgentRole)}>
              <SelectTrigger>
                <SelectValue placeholder="Select your role" />
              </SelectTrigger>
              <SelectContent>
                {roleOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FormFieldWrapper>
        </div>

        <Alert className="mt-8">
          <AlertTitle>Role Information</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4 space-y-2">
              <li>Listing Agent: Represents the seller in the transaction</li>
              <li>Buyer's Agent: Represents the buyer in the transaction</li>
              <li>Dual Agent: Represents both buyer and seller</li>
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </FormSectionContainer>
  );
};
