import React from 'react';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { FormFieldGroup } from '../components/FormFieldGroup';
import { FormInput } from '../../ui/form-input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { Button } from '../../ui/button';
import { Alert, AlertTitle, AlertDescription } from '../../ui/alert';
import { Plus, Trash2 } from 'lucide-react';
import { useFormSection } from '../../../hooks/useFormSection';
import { MaritalStatus, ClientInfo } from '../types';

const maritalStatusOptions: MaritalStatus[] = ["Single", "Married", "Divorce", "Widowed"];
const MAX_CLIENTS = 4;

export const ClientSection: React.FC = () => {
  const { formData, updateField, getFieldValidationState, getFieldError } = useFormSection({
    sectionName: 'client',
    sectionIndex: 2
  });

  const handleAddClient = () => {
    if (formData.clients.length < MAX_CLIENTS) {
      const newClients = [...formData.clients];
      newClients.push({
        name: '',
        address: '',
        email: '',
        phone: '',
        maritalStatus: 'Single',
        designation: ''
      });
      updateField('clients', newClients);
    }
  };

  const handleRemoveClient = (index: number) => {
    const newClients = [...formData.clients];
    newClients.splice(index, 1);
    updateField('clients', newClients);
  };

  const handleClientFieldChange = (index: number, field: keyof ClientInfo, value: string) => {
    const newClients = [...formData.clients];
    newClients[index] = {
      ...newClients[index],
      [field]: value
    };
    updateField('clients', newClients);
  };

  return (
    <FormSectionContainer>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">Client Information</h2>
          <div className="text-sm text-red-500">* Required</div>
        </div>

        <div className="space-y-8">
          {formData.clients.map((client, index) => (
            <FormFieldGroup
              key={index}
              title={`Client ${index + 1}`}
              description={`Enter information for client ${index + 1}`}
              className="relative"
            >
              {index > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-4 right-4"
                  onClick={() => handleRemoveClient(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}

              <div className="grid grid-cols-1 gap-y-6">
                <FormFieldWrapper
                  label="Full Name"
                  required
                  error={getFieldValidationState(`clients.${index}.name` as any) === 'invalid' ? getFieldError(`clients.${index}.name` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.name` as any) === 'warning' ? getFieldError(`clients.${index}.name` as any) : undefined}
                >
                  <FormInput
                    value={client.name}
                    onChange={(e) => handleClientFieldChange(index, 'name', e.target.value)}
                    placeholder="Enter client's full name"
                  />
                </FormFieldWrapper>

                <FormFieldWrapper
                  label="Address"
                  required
                  error={getFieldValidationState(`clients.${index}.address` as any) === 'invalid' ? getFieldError(`clients.${index}.address` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.address` as any) === 'warning' ? getFieldError(`clients.${index}.address` as any) : undefined}
                >
                  <FormInput
                    value={client.address}
                    onChange={(e) => handleClientFieldChange(index, 'address', e.target.value)}
                    placeholder="Enter client's address"
                  />
                </FormFieldWrapper>

                <FormFieldWrapper
                  label="Email"
                  required
                  error={getFieldValidationState(`clients.${index}.email` as any) === 'invalid' ? getFieldError(`clients.${index}.email` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.email` as any) === 'warning' ? getFieldError(`clients.${index}.email` as any) : undefined}
                >
                  <FormInput
                    type="email"
                    value={client.email}
                    onChange={(e) => handleClientFieldChange(index, 'email', e.target.value)}
                    placeholder="Enter client's email"
                  />
                </FormFieldWrapper>

                <FormFieldWrapper
                  label="Phone"
                  required
                  error={getFieldValidationState(`clients.${index}.phone` as any) === 'invalid' ? getFieldError(`clients.${index}.phone` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.phone` as any) === 'warning' ? getFieldError(`clients.${index}.phone` as any) : undefined}
                >
                  <FormInput
                    type="tel"
                    value={client.phone}
                    onChange={(e) => handleClientFieldChange(index, 'phone', e.target.value.replace(/[^0-9-]/g, ''))}
                    placeholder="XXX-XXX-XXXX"
                    maxLength={12}
                  />
                </FormFieldWrapper>

                <FormFieldWrapper
                  label="Marital Status"
                  required
                  error={getFieldValidationState(`clients.${index}.maritalStatus` as any) === 'invalid' ? getFieldError(`clients.${index}.maritalStatus` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.maritalStatus` as any) === 'warning' ? getFieldError(`clients.${index}.maritalStatus` as any) : undefined}
                >
                  <Select
                    value={client.maritalStatus}
                    onValueChange={(value) => handleClientFieldChange(index, 'maritalStatus', value as MaritalStatus)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select marital status" />
                    </SelectTrigger>
                    <SelectContent>
                      {maritalStatusOptions.map((status) => (
                        <SelectItem key={status} value={status}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormFieldWrapper>

                <FormFieldWrapper
                  label="Designation"
                  required
                  error={getFieldValidationState(`clients.${index}.designation` as any) === 'invalid' ? getFieldError(`clients.${index}.designation` as any) : undefined}
                  warning={getFieldValidationState(`clients.${index}.designation` as any) === 'warning' ? getFieldError(`clients.${index}.designation` as any) : undefined}
                >
                  <Select
                    value={client.designation}
                    onValueChange={(value) => handleClientFieldChange(index, 'designation', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select client designation" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Buyer">Buyer</SelectItem>
                      <SelectItem value="Seller">Seller</SelectItem>
                    </SelectContent>
                  </Select>
                </FormFieldWrapper>
              </div>
            </FormFieldGroup>
          ))}

          {formData.clients.length < MAX_CLIENTS && (
            <Button
              variant="outline"
              className="w-full"
              onClick={handleAddClient}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Another Client
            </Button>
          )}
        </div>

        <Alert className="mt-8">
          <AlertTitle>Client Information</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4 space-y-2">
              <li>You can add up to {MAX_CLIENTS} clients</li>
              <li>All fields are required for each client</li>
              <li>Phone numbers should be in XXX-XXX-XXXX format</li>
              <li>Each client must be designated as either a Buyer or Seller</li>
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </FormSectionContainer>
  );
};
