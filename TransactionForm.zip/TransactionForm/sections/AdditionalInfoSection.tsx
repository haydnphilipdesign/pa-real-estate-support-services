import React from 'react';
import { useFormSection } from '../../../hooks/useFormSection';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { FormInput } from '../../ui/form-input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { PropertyStatus, AccessType, TCFeePaidBy } from '../types';
import { FormFieldGroup, GridFieldGroup, ToggleFieldGroup, InfoBox } from '../components/FormFieldGroup';
import { Textarea } from '../../ui/textarea';

const propertyStatusOptions: PropertyStatus[] = ["Vacant", "Occupied"];
const accessTypeOptions: AccessType[] = ["Electronic Lock Box", "Call Occupant"];
const tcFeePaidByOptions: TCFeePaidBy[] = ["Client", "Agent"];

export const AdditionalInfoSection: React.FC = () => {
  const {
    formData,
    updateField,
    getFieldValidationState,
    getFieldError,
    getFieldHelpText
  } = useFormSection({
    sectionName: 'additional info',
    sectionIndex: 6
  });

  return (
    <FormSectionContainer>
      {/* Title Company Information */}
      <FormFieldGroup
        title="Title Company Information"
        className="col-span-2"
      >
        <FormFieldWrapper
          label="Title Company"
          error={getFieldValidationState('titleCompany') === 'error' ? getFieldError('titleCompany') : undefined}
          warning={getFieldValidationState('titleCompany') === 'warning' ? getFieldError('titleCompany') : undefined}
          helpText={getFieldHelpText('titleCompany')}
        >
          <FormInput
            value={formData.titleCompany}
            onChange={(e) => updateField('titleCompany', e.target.value)}
            placeholder="Enter title company name"
            state={getFieldValidationState('titleCompany')}
          />
        </FormFieldWrapper>

        <FormFieldWrapper
          label="Title Company Fee Paid By"
          error={getFieldValidationState('tcFeePaidBy') === 'error' ? getFieldError('tcFeePaidBy') : undefined}
          warning={getFieldValidationState('tcFeePaidBy') === 'warning' ? getFieldError('tcFeePaidBy') : undefined}
          helpText={getFieldHelpText('tcFeePaidBy')}
        >
          <Select value={formData.tcFeePaidBy} onValueChange={(value) => updateField('tcFeePaidBy', value as TCFeePaidBy)}>
            <SelectTrigger>
              <SelectValue placeholder="Select who pays the fee" />
            </SelectTrigger>
            <SelectContent>
              {tcFeePaidByOptions.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FormFieldWrapper>
      </FormFieldGroup>

      {/* Property Access Information */}
      <FormFieldGroup
        title="Property Access Information"
        className="col-span-2"
      >
        <GridFieldGroup>
          <FormFieldWrapper
            label="Property Status"
            error={getFieldValidationState('propertyStatus') === 'error' ? getFieldError('propertyStatus') : undefined}
            warning={getFieldValidationState('propertyStatus') === 'warning' ? getFieldError('propertyStatus') : undefined}
            helpText={getFieldHelpText('propertyStatus')}
          >
            <Select value={formData.propertyStatus} onValueChange={(value) => updateField('propertyStatus', value as PropertyStatus)}>
              <SelectTrigger>
                <SelectValue placeholder="Select property status" />
              </SelectTrigger>
              <SelectContent>
                {propertyStatusOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FormFieldWrapper>

          <FormFieldWrapper
            label="Access Information"
            error={getFieldValidationState('accessInformation') === 'error' ? getFieldError('accessInformation') : undefined}
            warning={getFieldValidationState('accessInformation') === 'warning' ? getFieldError('accessInformation') : undefined}
            helpText={getFieldHelpText('accessInformation')}
          >
            <Select value={formData.accessInformation} onValueChange={(value) => updateField('accessInformation', value as AccessType)}>
              <SelectTrigger>
                <SelectValue placeholder="Select access type" />
              </SelectTrigger>
              <SelectContent>
                {accessTypeOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FormFieldWrapper>
        </GridFieldGroup>

        {formData.accessInformation === "Electronic Lock Box" && (
          <FormFieldWrapper
            label="Access Code"
            required
            error={getFieldValidationState('accessCode') === 'error' ? getFieldError('accessCode') : undefined}
            warning={getFieldValidationState('accessCode') === 'warning' ? getFieldError('accessCode') : undefined}
            helpText={getFieldHelpText('accessCode')}
          >
            <FormInput
              value={formData.accessCode}
              onChange={(e) => updateField('accessCode', e.target.value)}
              placeholder="Enter access code"
              state={getFieldValidationState('accessCode')}
            />
          </FormFieldWrapper>
        )}

        <ToggleFieldGroup
          checked={formData.updateMLS}
          onToggle={(checked) => updateField('updateMLS', checked)}
          toggleLabel="Update MLS"
          toggleDescription="Check to update MLS with this information"
        >
          <></>
        </ToggleFieldGroup>
      </FormFieldGroup>

      {/* Additional Notes */}
      <FormFieldGroup
        title="Additional Notes"
        className="col-span-2"
      >
        <FormFieldWrapper
          label="Special Instructions"
          error={getFieldValidationState('specialInstructions') === 'error' ? getFieldError('specialInstructions') : undefined}
          warning={getFieldValidationState('specialInstructions') === 'warning' ? getFieldError('specialInstructions') : undefined}
          helpText={getFieldHelpText('specialInstructions')}
        >
          <Textarea
            value={formData.specialInstructions}
            onChange={(e) => updateField('specialInstructions', e.target.value)}
            placeholder="Enter any special instructions for this transaction"
            className="min-h-[100px]"
          />
        </FormFieldWrapper>

        <FormFieldWrapper
          label="Urgent Issues"
          error={getFieldValidationState('urgentIssues') === 'error' ? getFieldError('urgentIssues') : undefined}
          warning={getFieldValidationState('urgentIssues') === 'warning' ? getFieldError('urgentIssues') : undefined}
          helpText={getFieldHelpText('urgentIssues')}
        >
          <Textarea
            value={formData.urgentIssues}
            onChange={(e) => updateField('urgentIssues', e.target.value)}
            placeholder="List any urgent issues that need immediate attention"
            className="min-h-[100px]"
          />
        </FormFieldWrapper>

        <FormFieldWrapper
          label="Additional Notes"
          error={getFieldValidationState('additionalNotes') === 'error' ? getFieldError('additionalNotes') : undefined}
          warning={getFieldValidationState('additionalNotes') === 'warning' ? getFieldError('additionalNotes') : undefined}
          helpText={getFieldHelpText('additionalNotes')}
        >
          <Textarea
            value={formData.additionalNotes}
            onChange={(e) => updateField('additionalNotes', e.target.value)}
            placeholder="Add any additional notes or comments"
            className="min-h-[100px]"
          />
        </FormFieldWrapper>
      </FormFieldGroup>

      {/* Additional Information Tips */}
      <InfoBox
        className="col-span-2 mt-6"
        title="Additional Information Tips"
        items={[
          'Provide clear access instructions for all parties',
          'Include any special showing requirements',
          'Note any time-sensitive issues or deadlines',
          'Add relevant details for title company coordination'
        ]}
      />
    </FormSectionContainer>
  );
};