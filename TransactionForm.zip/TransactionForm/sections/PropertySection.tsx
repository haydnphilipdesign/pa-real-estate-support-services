import React from 'react';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { FormInput } from '../../ui/form-input';
import { Alert, AlertTitle, AlertDescription } from '../../ui/alert';
import { useFormSection } from '../../../hooks/useFormSection';
import { AddressAutocomplete } from '../../ui/AddressAutocomplete';

export const PropertySection: React.FC = () => {
  const { formData, updateField, getFieldValidationState, getFieldError } = useFormSection({
    sectionName: 'property',
    sectionIndex: 1
  });

  const handleAddressDetails = (details: any) => {
    // Try to extract township/municipality from address details
    const township = 
      details.fullComponents?.find((c: any) => c.types.includes('sublocality_level_1'))?.long_name ||
      details.fullComponents?.find((c: any) => c.types.includes('sublocality'))?.long_name ||
      details.fullComponents?.find((c: any) => c.types.includes('locality'))?.long_name ||
      details.fullComponents?.find((c: any) => c.types.includes('administrative_area_level_3'))?.long_name;

    if (township) {
      updateField("townshipName", township);
    }
  };

  return (
    <FormSectionContainer>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">Property Information</h2>
          <div className="text-sm text-red-500">* Required</div>
        </div>

        <div className="grid grid-cols-1 gap-y-6">
          <FormFieldWrapper
            label="MLS Number"
            required
            error={getFieldValidationState('mlsNumber') === 'invalid' ? getFieldError('mlsNumber') : undefined}
            warning={getFieldValidationState('mlsNumber') === 'warning' ? getFieldError('mlsNumber') : undefined}
          >
            <FormInput
              value={formData.mlsNumber}
              onChange={(e) => updateField('mlsNumber', e.target.value)}
              placeholder="Enter MLS number"
            />
          </FormFieldWrapper>

          <FormFieldWrapper
            label="Property Address"
            required
            error={getFieldValidationState('propertyAddress') === 'invalid' ? getFieldError('propertyAddress') : undefined}
            warning={getFieldValidationState('propertyAddress') === 'warning' ? getFieldError('propertyAddress') : undefined}
          >
            <AddressAutocomplete
              value={formData.propertyAddress}
              onChange={(value) => updateField('propertyAddress', value)}
              placeholder="Enter property address"
              includeDetails={true}
              onDetailsReceived={handleAddressDetails}
            />
          </FormFieldWrapper>

          <FormFieldWrapper
            label="Sale Price"
            required
            error={getFieldValidationState('salePrice') === 'invalid' ? getFieldError('salePrice') : undefined}
            warning={getFieldValidationState('salePrice') === 'warning' ? getFieldError('salePrice') : undefined}
          >
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                $
              </span>
              <FormInput
                value={formData.salePrice}
                onChange={(e) => updateField('salePrice', e.target.value.replace(/[^0-9.]/g, ''))}
                placeholder="0.00"
                className="pl-7"
                type="text"
                inputMode="decimal"
              />
            </div>
          </FormFieldWrapper>
        </div>

        <Alert className="mt-8">
          <AlertTitle>Property Information</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4 space-y-2">
              <li>MLS Number: The unique identifier for the property listing</li>
              <li>Property Address: The complete address of the property (use autocomplete for accuracy)</li>
              <li>Sale Price: The agreed-upon sale price of the property</li>
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </FormSectionContainer>
  );
};
