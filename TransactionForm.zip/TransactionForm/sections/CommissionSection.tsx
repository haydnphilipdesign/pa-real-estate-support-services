import React from 'react';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { FormFieldGroup } from '../components/FormFieldGroup';
import { FormInput } from '../../ui/form-input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';
import { CommissionBase, CommissionType, TCFeePaidBy } from '../types';
import { InfoBox } from '../components/FormFieldGroup';
import { useFormSection } from '../../../hooks/useFormSection';
import { formatCurrencyForDisplay } from '../../../utils/airtable';

const commissionBaseOptions: CommissionBase[] = ["Full Price", "Net Price"];
const tcFeePaidByOptions: TCFeePaidBy[] = ["Client", "Agent"];

const formatPercentage = (value: string | undefined): string => {
  if (!value) return '';
  const numValue = parseFloat(value);
  return isNaN(numValue) ? '' : numValue.toFixed(2);
};

export const CommissionSection: React.FC = () => {
  const {
    formData,
    updateField: onUpdate,
    getFieldValidationState: getValidationState,
    getFieldError
  } = useFormSection({
    sectionName: 'commission',
    sectionIndex: 3
  });

  const isBuyerAgent = formData.role === "Buyer's Agent";

  // Handle percentage input formatting
  const handlePercentageChange = (e: React.ChangeEvent<HTMLInputElement>, field: keyof typeof formData) => {
    const value = e.target.value.replace(/[^0-9.]/g, '');
    if (value === '') {
      onUpdate(field, '');
      return;
    }

    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue >= 0 && numValue <= 100) {
      onUpdate(field, numValue.toString());
    }
  };

  const handlePercentageBlur = (field: keyof typeof formData) => {
    if (formData[field]) {
      const numValue = parseFloat(formData[field] as string);
      if (!isNaN(numValue)) {
        onUpdate(field, numValue.toFixed(2));
      }
    }
  };

  // Auto-calculate commission splits
  React.useEffect(() => {
    if (!isBuyerAgent && formData.totalCommission && formData.listingAgentCommission) {
      const total = parseFloat(formData.totalCommission);
      const listing = parseFloat(formData.listingAgentCommission);
      if (!isNaN(total) && !isNaN(listing) && listing <= total) {
        const buyers = total - listing;
        onUpdate('buyersAgentCommission', buyers.toFixed(2));
      }
    }
  }, [formData.totalCommission, formData.listingAgentCommission, isBuyerAgent]);

  return (
    <FormSectionContainer>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">Commission Information</h2>
          <div className="text-sm text-red-500">* Required</div>
        </div>

        <div className="grid grid-cols-2 gap-x-8 gap-y-6">
          {/* Commission Base - Hide for Buyer's Agent */}
          {!isBuyerAgent && (
            <FormFieldWrapper
              label="Commission Base"
              required
              error={getValidationState('commissionBase') === 'invalid' ? getFieldError('commissionBase') : undefined}
              warning={getValidationState('commissionBase') === 'warning' ? getFieldError('commissionBase') : undefined}
            >
              <Select value={formData.commissionBase} onValueChange={(value) => onUpdate('commissionBase', value as CommissionBase)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select commission base" />
                </SelectTrigger>
                <SelectContent>
                  {commissionBaseOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormFieldWrapper>
          )}

          {/* Total Commission - Hide for Buyer's Agent */}
          {!isBuyerAgent && (
            <FormFieldWrapper
              label="Total Commission"
              required
              error={getValidationState('totalCommission') === 'invalid' ? getFieldError('totalCommission') : undefined}
              warning={getValidationState('totalCommission') === 'warning' ? getFieldError('totalCommission') : undefined}
            >
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  %
                </span>
                <FormInput
                  value={formatPercentage(formData.totalCommission)}
                  onChange={(e) => handlePercentageChange(e, 'totalCommission')}
                  onBlur={() => handlePercentageBlur('totalCommission')}
                  placeholder="0.00"
                  className="w-full pl-7"
                  state={getValidationState('totalCommission')}
                  type="text"
                  inputMode="decimal"
                />
              </div>
            </FormFieldWrapper>
          )}

          {/* Listing Agent Commission */}
          {(formData.role === "Listing Agent" || formData.role === "Dual Agent") && (
            <FormFieldWrapper
              label="Listing Agent Commission"
              required
              error={getValidationState('listingAgentCommission') === 'invalid' ? getFieldError('listingAgentCommission') : undefined}
              warning={getValidationState('listingAgentCommission') === 'warning' ? getFieldError('listingAgentCommission') : undefined}
            >
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  %
                </span>
                <FormInput
                  value={formatPercentage(formData.listingAgentCommission)}
                  onChange={(e) => handlePercentageChange(e, 'listingAgentCommission')}
                  onBlur={() => handlePercentageBlur('listingAgentCommission')}
                  placeholder="0.00"
                  className="w-full pl-7"
                  state={getValidationState('listingAgentCommission')}
                  type="text"
                  inputMode="decimal"
                />
              </div>
            </FormFieldWrapper>
          )}

          {/* Buyer's Agent Commission */}
          <FormFieldWrapper
            label="Buyer's Agent Commission"
            required
            error={getValidationState('buyersAgentCommission') === 'invalid' ? getFieldError('buyersAgentCommission') : undefined}
            warning={getValidationState('buyersAgentCommission') === 'warning' ? getFieldError('buyersAgentCommission') : undefined}
          >
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                %
              </span>
              <FormInput
                value={formatPercentage(formData.buyersAgentCommission)}
                onChange={(e) => handlePercentageChange(e, 'buyersAgentCommission')}
                onBlur={() => handlePercentageBlur('buyersAgentCommission')}
                placeholder="0.00"
                className="w-full pl-7"
                state={getValidationState('buyersAgentCommission')}
                type="text"
                inputMode="decimal"
                readOnly={!isBuyerAgent}
              />
            </div>
          </FormFieldWrapper>
        </div>

        {/* Referral Information */}
        <FormFieldGroup title="Referral Information" description="Enter referral details if applicable" className="mt-8">
          <div className="grid grid-cols-2 gap-x-8 gap-y-6">
            <FormFieldWrapper
              label="Referral Party"
              error={getValidationState('referralParty') === 'invalid' ? getFieldError('referralParty') : undefined}
              warning={getValidationState('referralParty') === 'warning' ? getFieldError('referralParty') : undefined}
            >
              <FormInput
                value={formData.referralParty}
                onChange={(e) => onUpdate('referralParty', e.target.value)}
                placeholder="Enter referral party name"
                className="w-full"
              />
            </FormFieldWrapper>

            <FormFieldWrapper
              label="Broker EIN"
              error={getValidationState('brokerEIN') === 'invalid' ? getFieldError('brokerEIN') : undefined}
              warning={getValidationState('brokerEIN') === 'warning' ? getFieldError('brokerEIN') : undefined}
            >
              <FormInput
                value={formData.brokerEIN}
                onChange={(e) => onUpdate('brokerEIN', e.target.value.replace(/[^0-9-]/g, ''))}
                placeholder="XX-XXXXXXX"
                maxLength={10}
                className="w-full"
              />
            </FormFieldWrapper>

            <FormFieldWrapper
              label="Referral Fee"
              error={getValidationState('referralFee') === 'invalid' ? getFieldError('referralFee') : undefined}
              warning={getValidationState('referralFee') === 'warning' ? getFieldError('referralFee') : undefined}
            >
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  %
                </span>
                <FormInput
                  value={formatPercentage(formData.referralFee)}
                  onChange={(e) => handlePercentageChange(e, 'referralFee')}
                  onBlur={() => handlePercentageBlur('referralFee')}
                  placeholder="0.00"
                  className="w-full pl-7"
                  type="text"
                  inputMode="decimal"
                />
              </div>
            </FormFieldWrapper>
          </div>
        </FormFieldGroup>

        {/* TC Fee Information */}
        <FormFieldGroup title="Transaction Coordinator Fee" className="mt-8">
          <div className="grid grid-cols-2 gap-x-8 gap-y-6">
            <FormFieldWrapper
              label="TC Fee Paid By"
              error={getValidationState('tcFeePaidBy') === 'invalid' ? getFieldError('tcFeePaidBy') : undefined}
              warning={getValidationState('tcFeePaidBy') === 'warning' ? getFieldError('tcFeePaidBy') : undefined}
            >
              <Select value={formData.tcFeePaidBy} onValueChange={(value) => onUpdate('tcFeePaidBy', value as TCFeePaidBy)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select who pays the TC fee" />
                </SelectTrigger>
                <SelectContent>
                  {tcFeePaidByOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormFieldWrapper>
          </div>
        </FormFieldGroup>

        {/* Commission Information Tips */}
        <InfoBox
          className="mt-8"
          title="Commission Calculation Tips"
          items={[
            'Enter commission percentages with up to 2 decimal places',
            isBuyerAgent ? 
              'Enter your commission percentage as provided by the listing agent' :
              'Total commission will be split between listing and buyer agents',
            'Commission base affects final commission calculation',
            'Include referral information if applicable'
          ]}
        />
      </div>
    </FormSectionContainer>
  );
};