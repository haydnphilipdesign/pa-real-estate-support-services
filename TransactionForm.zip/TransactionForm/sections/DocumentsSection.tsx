import React from 'react';
import { FormSectionContainer, FormFieldWrapper } from '../components/BaseFormSection';
import { Checkbox } from '../../ui/checkbox';
import { Alert, AlertTitle, AlertDescription } from '../../ui/alert';
import { useFormSection } from '../../../hooks/useFormSection';
import { Info, AlertCircle, CheckCircle, Home, Key } from 'lucide-react';
import { cn } from '../../../lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '../../ui/tooltip';
import { Switch } from '../../ui/switch';
import { FormFieldGroup } from '../components/FormFieldGroup';
import { Separator } from '../../ui/separator';

interface DocumentGroup {
  title: string;
  documents: {
    name: string;
    required: boolean;
    description: string;
  }[];
}

const documentGroups: { [key: string]: DocumentGroup[] } = {
  "Buyer's Agent": [
    {
      title: "Transaction Documents",
      documents: [
        { name: "Agreement of Sale & Addenda", required: true, description: "Primary contract and any additional terms" },
        { name: "Attorney Review Clause", required: true, description: "Legal review period terms" },
        { name: "Deposit Money Notice", required: true, description: "Details of earnest money handling" },
        { name: "Buyer's Agency Contract", required: true, description: "Exclusive buyer agency agreement" },
        { name: "Estimated Closing Costs", required: true, description: "Detailed breakdown of buyer's expenses" }
      ]
    },
    {
      title: "Disclosures",
      documents: [
        { name: "KW Affiliate Services Disclosure", required: true, description: "Required affiliated business disclosure" },
        { name: "Consumer Notice", required: true, description: "State-mandated consumer notice" },
        { name: "Lead Based Paint Disclosure", required: false, description: "Required for homes built before 1978" },
        { name: "Seller's Property Disclosure", required: true, description: "Property condition disclosure from seller" },
        { name: "HOA/Condo Documents", required: false, description: "If property is in HOA/Condo association" }
      ]
    },
    {
      title: "Financial Documents",
      documents: [
        { name: "Prequalification Letter", required: true, description: "Lender prequalification verification" },
        { name: "Proof of Funds", required: true, description: "For cash purchases or down payment" },
        { name: "Commission Agreement", required: true, description: "Broker compensation terms" }
      ]
    },
    {
      title: "Additional Documents",
      documents: [
        { name: "Wire Fraud Advisory", required: true, description: "Wire transfer security information" },
        { name: "Home Warranty Information", required: false, description: "If home warranty is requested" },
        { name: "Municipal Requirements", required: false, description: "City/township specific requirements" },
        { name: "Inspection Reports", required: false, description: "If inspections are performed" }
      ]
    }
  ],
  "Listing Agent": [
    {
      title: "Listing Documents",
      documents: [
        { name: "Listing Agreement", required: true, description: "Exclusive listing contract" },
        { name: "Seller's Property Disclosure", required: true, description: "Required property condition disclosure" },
        { name: "Lead Based Paint Disclosure", required: false, description: "Required for homes built before 1978" }
      ]
    },
    {
      title: "Transaction Documents",
      documents: [
        { name: "Agreement of Sale", required: true, description: "Primary contract document" },
        { name: "Addenda", required: false, description: "Additional contract terms if applicable" },
        { name: "Estimated Seller Proceeds", required: true, description: "Net proceeds calculation" }
      ]
    },
    {
      title: "Property Documents",
      documents: [
        { name: "Title Documents", required: true, description: "Current deed and title information" },
        { name: "HOA/Condo Documents", required: false, description: "If property is in association" },
        { name: "Survey", required: false, description: "Property survey if available" }
      ]
    },
    {
      title: "Required Disclosures",
      documents: [
        { name: "KW Affiliate Services Disclosure", required: true, description: "Required affiliated business disclosure" },
        { name: "Wire Fraud Advisory", required: true, description: "Wire transfer security information" },
        { name: "Municipal Requirements", required: false, description: "City/township specific requirements" }
      ]
    }
  ],
  "Dual Agent": [
    {
      title: "Core Transaction Documents",
      documents: [
        { name: "Agreement of Sale & Addenda", required: true, description: "Primary contract and additional terms" },
        { name: "Dual Agency Disclosure", required: true, description: "Required dual representation disclosure" },
        { name: "Deposit Money Notice", required: true, description: "Details of earnest money handling" },
        { name: "Attorney Review Clause", required: true, description: "Legal review period terms" }
      ]
    },
    {
      title: "Buyer Side Documents",
      documents: [
        { name: "Buyer's Agency Contract", required: true, description: "Buyer representation agreement" },
        { name: "Buyer's Estimated Costs", required: true, description: "Detailed breakdown of buyer's expenses" },
        { name: "Prequalification Letter", required: true, description: "Lender prequalification verification" },
        { name: "Proof of Funds", required: true, description: "For cash purchases or down payment" }
      ]
    },
    {
      title: "Seller Side Documents",
      documents: [
        { name: "Listing Agreement", required: true, description: "Exclusive listing contract" },
        { name: "Seller's Property Disclosure", required: true, description: "Required property condition disclosure" },
        { name: "Estimated Seller Proceeds", required: true, description: "Net proceeds calculation" },
        { name: "Title Documents", required: true, description: "Current deed and title information" }
      ]
    },
    {
      title: "Required Disclosures",
      documents: [
        { name: "KW Affiliate Services Disclosure", required: true, description: "Required affiliated business disclosure" },
        { name: "Consumer Notice", required: true, description: "State-mandated consumer notice" },
        { name: "Lead Based Paint Disclosure", required: false, description: "Required for homes built before 1978" },
        { name: "Wire Fraud Advisory", required: true, description: "Wire transfer security information" },
        { name: "HOA/Condo Documents", required: false, description: "If property is in association" },
        { name: "Municipal Requirements", required: false, description: "City/township specific requirements" }
      ]
    }
  ]
};

export const DocumentsSection: React.FC = () => {
  const { formData, updateField, getFieldValidationState, getFieldError } = useFormSection({
    sectionName: 'documents',
    sectionIndex: 5
  });

  const currentGroups = documentGroups[formData.role] || [];
  const validationState = getFieldValidationState('requiredDocuments');
  const error = getFieldError('requiredDocuments');

  const handleDocumentChange = (documentName: string, checked: boolean) => {
    const updatedDocuments = checked
      ? [...formData.requiredDocuments, documentName]
      : formData.requiredDocuments.filter(doc => doc !== documentName);
    updateField('requiredDocuments', updatedDocuments);
  };

  const isDocumentComplete = (group: DocumentGroup) => {
    return group.documents
      .filter(doc => doc.required)
      .every(doc => formData.requiredDocuments.includes(doc.name));
  };

  const isListingOrDualAgent = formData.role === "Listing Agent" || formData.role === "Dual Agent";

  return (
    <FormSectionContainer>
      <div className="p-6 space-y-8">
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">Required Documents</h2>
            <div className="text-sm text-red-500">* Required</div>
          </div>

          <div className="bg-blue-50/50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-500 mt-0.5" />
              <div>
                <p className="text-sm text-blue-800">
                  Please confirm that all required documents have been uploaded to either DocuSign or Dotloop.
                  These documents are necessary for transaction compliance.
                </p>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
                <div>
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-8">
            <AnimatePresence mode="wait">
              {currentGroups.map((group, groupIndex) => (
                <motion.div
                  key={group.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: groupIndex * 0.1 }}
                  className={cn(
                    "border rounded-xl p-6",
                    "bg-white shadow-sm",
                    isDocumentComplete(group) 
                      ? "border-emerald-200 bg-emerald-50/30" 
                      : "border-gray-200"
                  )}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-gray-900">{group.title}</h3>
                    {isDocumentComplete(group) && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-emerald-500"
                      >
                        <CheckCircle className="w-5 h-5" />
                      </motion.div>
                    )}
                  </div>

                  <div className="space-y-4">
                    {group.documents.map((document) => (
                      <div key={document.name} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Checkbox
                            id={document.name}
                            checked={formData.requiredDocuments.includes(document.name)}
                            onCheckedChange={(checked) => handleDocumentChange(document.name, checked as boolean)}
                            className={cn(
                              document.required && "border-2",
                              document.required && !formData.requiredDocuments.includes(document.name) 
                                ? "border-red-500" 
                                : "border-gray-200"
                            )}
                          />
                          <div className="space-y-1">
                            <label
                              htmlFor={document.name}
                              className={cn(
                                "text-sm font-medium cursor-pointer",
                                document.required ? "text-gray-900" : "text-gray-600"
                              )}
                            >
                              {document.name}
                              {document.required && <span className="text-red-500 ml-1">*</span>}
                            </label>
                          </div>
                        </div>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Info className="w-4 h-4 text-gray-400 hover:text-gray-600 transition-colors" />
                            </TooltipTrigger>
                            <TooltipContent side="left" className="max-w-xs">
                              <p className="text-sm">{document.description}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        <Separator className="my-8" />

        <FormFieldGroup
          title="Property Status"
          description="Update property condition and access information"
          icon={Home}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormFieldWrapper
              label="Winterized Status"
              helpText="Select the current winterization status of the property"
            >
              <Select
                value={formData.winterizedStatus || ''}
                onValueChange={(value) => updateField('winterizedStatus', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select winterization status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_winterized">Not Winterized</SelectItem>
                  <SelectItem value="winterized">Winterized</SelectItem>
                  <SelectItem value="partial">Partially Winterized</SelectItem>
                  <SelectItem value="not_applicable">Not Applicable</SelectItem>
                </SelectContent>
              </Select>
            </FormFieldWrapper>

            <FormFieldWrapper
              label="Access Information"
              helpText="Specify how to access the property"
            >
              <Select
                value={formData.accessType || ''}
                onValueChange={(value) => updateField('accessType', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select access type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lockbox">Lockbox</SelectItem>
                  <SelectItem value="key">Key at Office</SelectItem>
                  <SelectItem value="appointment">By Appointment Only</SelectItem>
                  <SelectItem value="occupied">Occupied - Contact Seller</SelectItem>
                  <SelectItem value="other">Other (Specify in Notes)</SelectItem>
                </SelectContent>
              </Select>
            </FormFieldWrapper>
          </div>
        </FormFieldGroup>

        {isListingOrDualAgent && (
          <FormFieldGroup
            title="MLS Status Update"
            description="Update the MLS status for this property"
            icon={Key}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-gray-900">
                    Update MLS Status to Pending
                  </label>
                  <p className="text-sm text-gray-500">
                    Automatically update the MLS status to "Pending" upon form submission
                  </p>
                </div>
                <Switch
                  checked={formData.updateMlsStatus || false}
                  onCheckedChange={(checked) => updateField('updateMlsStatus', checked)}
                />
              </div>

              {formData.updateMlsStatus && (
                <Alert>
                  <AlertTitle>MLS Update Confirmation</AlertTitle>
                  <AlertDescription>
                    The MLS status will be automatically updated to "Pending" when you submit this form.
                    Make sure all required documents are properly uploaded before proceeding.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </FormFieldGroup>
        )}
      </div>
    </FormSectionContainer>
  );
};